from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
import joblib
# Load model dan scaler
model = joblib.load("model_stunting.pkl")
scaler = joblib.load("scaler.pkl")

# Inisialisasi FastAPI
app = FastAPI(
    title="Stunting Prediction API",
    description="API untuk prediksi stunting menggunakan Machine Learning",
    version="1.0.0"
)

# Schema input
class PredictRequest(BaseModel):
    usia: float
    tinggi_badan: float
    berat_badan: float
    jenis_kelamin: float

# Root endpoint
@app.get("/")
def home():
    return {
        "message": "Stunting Prediction API aktif"
    }

# Endpoint predict
@app.post("/predict")
def predict(data: PredictRequest):
    try:
        # Convert input ke array
        input_data = np.array([
            [
                data.usia,
                data.tinggi_badan,
                data.berat_badan,
                data.jenis_kelamin
            ]
        ])

        # Scaling
        scaled_data = scaler.transform(input_data)

        # Prediksi
        prediction = model.predict(scaled_data)

        # Probability
        probability = None
        if hasattr(model, "predict_proba"):
            probability = model.predict_proba(scaled_data).tolist()

        # Tambahan label
        label = "Stunting" if prediction[0] == 1 else "Tidak Stunting"

        # Return response
        return {
            "prediction": int(prediction[0]),
            "label": label,
            "probability": probability
        }

    except Exception as e:
        return {
            "error": str(e)
        }